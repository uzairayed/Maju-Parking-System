This project has been created with the help of PHP and MYSQL and it is executed through XAMPP, a PHP software. In order to make it work, Install XAMPP, and unzip this project in Xampp/htdocs/(here)


In case of any difficulty, contact : SP21BSCS0070@maju.edu.pk